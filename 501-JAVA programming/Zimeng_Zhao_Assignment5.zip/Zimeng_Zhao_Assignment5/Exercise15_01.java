package application;
//Zimeng Zhao
//20012231
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.geometry.Pos;
import javafx.geometry.Insets;
import javafx.scene.layout.Pane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.BorderRepeat;
import javafx.scene.control.Button;
import javafx.scene.shape.Circle;


public class Exercise15_01 extends Application {

	public void start(Stage primaryStage) throws Exception {
		
		double width = 300;
		double height = 150;
		
		BallPane ballPane = new BallPane();
		
		Button left = new Button("left");
		left.setOnAction(e -> ballPane.left());
		
		Button right = new Button("right");
		right.setOnAction(e -> ballPane.right());
		
		Button up = new Button("up");
		up.setOnAction(e -> ballPane.up());
		
		Button down = new Button("down");
		down.setOnAction(e -> ballPane.down());
		
		HBox button = new HBox(left, right, up, down);
		button.setAlignment(Pos.BOTTOM_CENTER);
		button.setSpacing(10);
		button.setPadding(new Insets(10,10,10,10));
		
		BorderPane pane = new BorderPane();
		pane.setCenter(ballPane);
		pane.setBottom(button);
		
		Scene scene = new Scene(pane, width, height);
		primaryStage.setScene(scene);
		primaryStage.setTitle("Exercise15_03");
		primaryStage.show();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

}
