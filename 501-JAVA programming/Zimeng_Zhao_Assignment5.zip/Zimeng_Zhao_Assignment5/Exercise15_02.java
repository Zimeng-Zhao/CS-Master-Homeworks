package application;
//Zimeng Zhao
//20012231
import javafx.application.Application;
import javafx.animation.PathTransition;
import javafx.animation.Timeline;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import javafx.scene.shape.Circle;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Exercise15_02 extends Application {

	public void start(Stage primaryStage) {
		
		Pane pane = new Pane();
		Arc arc = new Arc(100, 100, 90, 90, -30 , -120);
		arc.setFill(Color.WHITE);
		arc.setStroke(Color.BLACK);
	
		Circle circle = new Circle(100 , 90, 8);
		pane.getChildren().addAll(arc, circle);
		
		PathTransition path = new PathTransition();
		path.setPath(arc);
		path.setNode(circle);
		path.setDuration(Duration.millis(5000));
		path.setOrientation(PathTransition.OrientationType.ORTHOGONAL_TO_TANGENT);
		path.setCycleCount(Timeline.INDEFINITE);
		path.setAutoReverse(true);
		path.play();
		
		pane.setOnMousePressed(e -> {path.pause();});
		pane.setOnMouseReleased(e -> {path.play();});
		
		Scene scene = new Scene(pane, 360, 300);
		primaryStage.setTitle("Exercise15_24");
		primaryStage.setScene(scene);
		primaryStage.show();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

}
