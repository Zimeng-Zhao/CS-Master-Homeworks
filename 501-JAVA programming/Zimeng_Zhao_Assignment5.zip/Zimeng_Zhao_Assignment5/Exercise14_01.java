package application;
//Zimeng Zhao
//20012231
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;


public class Exercise14_01 extends Application {

	public void start(Stage primaryStage) {
		GridPane pane = new GridPane();
		pane.add(new ImageView(new Image("file:Q1\\ca.gif")), 0, 0);;//image/._ca.gif
		pane.add(new ImageView(new Image("file:Q1\\china.gif")), 1, 0);
		pane.add(new ImageView(new Image("file:Q1\\uk.gif")), 0, 1);
		pane.add(new ImageView(new Image("file:Q1\\us.gif")), 1, 1);
		
		Scene scene = new Scene(pane);
		primaryStage.setTitle("Exercise14_01");
		primaryStage.setScene(scene);
		primaryStage.show();
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

}
