package homework;
//Zimeng Zhao
//20012231
import java.util.Scanner;

public class Exercise18_01  {
	
	private static double m(double i) {
		if(i == 1) {
			return 1;
		}
		else {
			return 1 / i + m(i - 1);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for(int i = 1; i <= 10; i++) {
			System.out.println("m (" + i + " ) = " + m(i));
		}

	
	}

}
