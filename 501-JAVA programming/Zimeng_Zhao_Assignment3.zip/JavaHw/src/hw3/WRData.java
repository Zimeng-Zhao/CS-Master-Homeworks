package hw3;
import java.util.Scanner;
import java.io.*;
import java.util.Random;
import java.util.ArrayList;
import java.util.Collections;


public class WRData {

	public static void main(String[] args) throws java.io.IOException{
		//  method 
		java.io.File file = new java.io.File("Java_Program.txt");
		if (file.exists()) {
			System.out.println("The file aready exits");
			System.exit(1);
		}
		
		PrintWriter writer = new PrintWriter(file);
		
		Random Integers = new Random();
		for(int i = 0; i <100; i++) {
		writer.print(Integers.nextInt());
		writer.print(" ");
		}
		writer.close();
		
		Scanner reader = new Scanner(file);
		ArrayList<Integer> intList = new ArrayList<>();
		
		while(reader.hasNext()) {
			intList.add(reader.nextInt());
			Collections.sort(intList);
		}
		System.out.print(intList.toString());
		System.out.println();
		reader.close();	
		}
	}
	

		
		
