package hw3;

import java.io.*; 
import java.util.List; 
import java.util.ArrayList;
import java.util.Scanner;
  
public class ListOfNumbers { 
    private List<Integer> list; 
    private static final int SIZE = 10; 
  
    public ListOfNumbers () { 
        list = new ArrayList<Integer>(SIZE); 
        for (int i = 0; i < SIZE; i++) 
            list.add(new Integer(i)); 
    } 
    
    
    public void writeList() { 
        PrintWriter out = null; 
        try { 
            System.out.println("Entering try statement"); 
            out = new PrintWriter(new FileWriter("outFile.txt")); 
            for (int i = 0; i < SIZE; i++) 
                out.println("Value at: " + i + " = " + list.get(i)); 
        } catch (IndexOutOfBoundsException e) { 
            System.err.println("Caught IndexOutOfBoundsException: " + 
                                 e.getMessage()); 
        } catch (IOException e) { 
            System.err.println("Caught IOException: " + e.getMessage()); 
        } finally { 
            if (out != null) { 
                System.out.println("Closing PrintWriter"); 
                out.close(); 
            } else { 
                System.out.println("PrintWriter not open"); 
            } 
        } 
    } 
	
    public void readList() throws Exception {
    	Scanner input = null;
    	try {
    	java.io.File file = new java.io.File("numberfile.txt");
    	input = new Scanner(file);
    	while(input.hasNext()) {
    		int values = input.nextInt();
    		System.out.println(values + " ");
    		list.add(values);
    	}
    	
    }
    	catch(Exception e){
    	System.err.println("Caught Exception: " + e.getMessage());
    }
    	finally {
    		if(input != null) {
    		input.close();
    		}
    }
    }
	

	
	
//	
//	public static void main(String[] args)throws Exception{
//		// TODO Auto-generated method stub
//		ListOfNumbers l = new ListOfNumbers();
//		l.readList();
//	
//	}

}
