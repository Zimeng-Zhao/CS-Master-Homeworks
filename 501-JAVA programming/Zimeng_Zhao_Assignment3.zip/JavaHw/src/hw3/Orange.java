package hw3;

public class Orange extends Citris {
	String type;
	
	Orange(){
		super();
	}
	
	Orange(String type, String taste, boolean rotten){
		super(taste, "orange", rotten);
		this.type = type;
	}
	
	public String getType() {
		return this.type;
	}
	
	public void setType(String type) {
		this.type = type;
	}
	
	public String toString() {
		return super.toString() + " type : " + this.getType() ;
		//+  "taste : " + this.taste + "rotten : " + this.rotten
	}
	
	public boolean equals(Object o) {
		if(o instanceof Orange) {
			return color == ((Orange)o).color && rotten == ((Orange)o).rotten && taste == ((Orange)o).taste && type == ((Orange)o).type;
		}
		else {
			return false;
		}
	}
	
	public static void main(String[] args) {
		Orange o = new Orange("citris", "good", true);
		System.out.println(o.toString());

	}
}
