package hw3;
import java.io.*;
import java.util.*;

public class ReformatJavaSourceCode {
	
	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		File file = new File("D:\\eclipse-workspace\\JavaHw\\src\\hw3\\q.java");
		if (args.length != 1) {
			System.out.println("There should be only 1 args");
			System.exit(1);
		}
		
		if(!file.exists()) {
			System.out.println("file " + "q.java" + "doen't exist");
			System.exit(1);
		}
		
		ArrayList<String> list = new ArrayList<>();	
		
		 try
	        {
	        	Scanner input = new Scanner(file);
	        	String var = "";
	        	while (input.hasNext()) {    
	        		String a = input.nextLine();
	                if(a.trim().equals("{"))
	                {
	                	var += "{";
	                }
	                else
	                {
	                	list.add(var);
	                	var = a;
	                }	
	            }
	        	list.add(var);
	        	PrintWriter output = new PrintWriter(file);
	        	for(int i = 1; i < list.size(); i++)
	        	{
	        		output.println(list.get(i));
	        	}
	        	input.close(); 
	        	output.close();
	        }
	        catch(Exception e)
	        {
	        	System.out.print(e);
	        }
		}
	}


