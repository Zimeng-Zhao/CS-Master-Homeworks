package hw3;

public class Apple extends Fruit {
	String taste;
	String texture;
	
	Apple(){
		super();
	}
	
	Apple( String taste, String texture, String color, boolean rotten){
		super(color, rotten);
		this.taste = taste;
		this.texture = texture;
	}

	public String getTaste() {
		return this.taste;
	}
	
	public void setTaste(String taste) {
		this.taste = taste;
	}
	
	public String getTexture(){
		return this.texture;
	}
	
	public void setTexture(String texture) {
		this.texture = texture;
	}
	
	public String toString() {
		return  " taste : " + this.taste +" texture : " + this.texture + super.toString();
	}
	
	public boolean equals(Object o) {//这里是否不应该加入taste and texture
		if(o instanceof Apple) {
			return color == ((Apple)o).color && rotten == ((Apple)o).rotten && taste == ((Apple)o).taste && texture == ((Apple)o).texture;
		}
		else {
			return false;
		}
	}
	
	
	
	
	public static void main(String[] args) {
		Apple a = new Apple("good", "good", "white", true);
		System.out.println(a.toString());
//		System.out.println(a.getId());

	}

}
