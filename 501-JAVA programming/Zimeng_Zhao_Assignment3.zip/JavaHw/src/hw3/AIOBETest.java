package hw3;
import java.util.Scanner;
import java.util.Random;


public class AIOBETest {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		try {
		int[] array = new int[100];
		Random number = new Random();
		for(int i =0; i < array.length; i++) {
			array[i] = number.nextInt();
		}
		
		Scanner input = new Scanner(System.in);
		System.out.println("Please enter an index of the array : ");
		int index = input.nextInt();
		int value = array[index];
		System.out.println("The value is " + value);
	}
		catch(Exception e){
			System.out.println("Out of Bounds ");
		}
   }
}
