package hw3;

public class Lemon extends Citris {
	int sourness;
	
	Lemon(){
		super();
	}
	
	Lemon(int sourness, String taste, boolean rotten){
		super(taste, "yellow", rotten);
		this.sourness = sourness;
}

	public int getSourness() {
		return this.sourness;
	}
	
	public void setSourness(int sourness) {
		this.sourness = sourness;
	}
	
	public String toString() {
		return " sourness : " + this.getSourness() + super.toString();
		// + "rotten : " + this.rotten + "taste : " + this.taste
	}
	
	public boolean equals(Object o) {
		if(o instanceof Citris) {
			return color == ((Lemon)o).color && rotten == ((Lemon)o).rotten && taste == ((Lemon)o).taste && sourness == ((Lemon)o).sourness;
		}
		else {
			return false;
		}
	}
	
	public static void main(String[] args) {
		Lemon l = new Lemon(3, "good", true);
		System.out.println(l.toString());

}
}
	