package hw3;
import java.util.ArrayList;
import java.util.Random;

public class FruitTest {
	
	public static void main(String[] args) throws Exception{
		// create 8 Fruit objects
		Apple fruit1 = new Apple("sweet", "crisp", "red", false);
		Apple fruit2 = new Apple("tart", "soft", "green", true);
		Apple fruit3 = new Apple("tart", "soft", "green", true);
		
		Random sourValue = new Random();
		Lemon fruit4 = new Lemon(sourValue.nextInt(101),"sour", false);
		Lemon fruit5 = new Lemon(sourValue.nextInt(101),"sour", false);
		Lemon fruit6 = new Lemon(sourValue.nextInt(101),"sour", false);
		
		Orange fruit7 = new Orange("mandarin", "sweet", true);
		Orange fruit8 = new Orange("mandarin", "sweet", true);
		
		ArrayList<Fruit> fruitTest = new ArrayList<>(); 
		
		//add 8 Fruit objects to the arraylist
		fruitTest.add(fruit1);
		fruitTest.add(fruit2);
		fruitTest.add(fruit3);
		fruitTest.add(fruit4);
		fruitTest.add(fruit5);
		fruitTest.add(fruit6);
		fruitTest.add(fruit7);
		fruitTest.add(fruit8);
		
		//print out the average sourness of all the Lemon objects in the Arraylist
		Lemon tureLemon;
		int count = 0;
		int total = 0;
		for(int i = 0; i < fruitTest.size(); i++) {
			if(fruitTest.get(i) instanceof Lemon) {
				tureLemon = (Lemon)fruitTest.get(i);
				System.out.println(tureLemon);
				count++;
				total += tureLemon.getSourness();	
			}
		}
		try {	
		System.out.println(total / count);
		}
		catch(Exception E){
			
		}
		
		//remove the matching object
		Fruit trueApple;
		Apple apple1 = null;
		for(int i = 0; i <fruitTest.size(); i++) {
			if(fruitTest.get(i) instanceof Apple) {
				trueApple = fruitTest.get(i);
				Apple apple = (Apple)trueApple;
				if((apple.getColor()).equalsIgnoreCase("green") && apple.isRotten()) {
					apple1 = apple;
					break;
				}
			}
		}
		System.out.println(" Retain the 1st rotten green Apple : " + apple1);
		
		for(int i = 0; i <fruitTest.size(); i++) {
			if(fruitTest.get(i) instanceof Apple && fruitTest.get(i).equals(apple1)) {
				System.out.println(fruitTest.get(i));
				fruitTest.set(i, null);
			}
		}
		
		for(int i = 0; i <fruitTest.size(); i++) {
			if(fruitTest.get(i) != null) {
				System.out.println(" Remaining objects are : " + fruitTest.get(i));
			}
		}
	}

}
