package hw3;

public class Citris extends Fruit {
	String taste;
	
	Citris(){
		super();
	}
	
	Citris(String taste, String color, boolean rotten){
		super(color, rotten);
		this.taste = taste;
	}
	
	public String getTaste() {
		return this.taste;
	}
	
	public void setTaste(String taste) {
		this.taste = taste;
	}
	
	public String toString() {
		return " taste : "+ this.taste + super.toString();
		// + " color : " + this.color + " rotten : " + this.rotten 
	}

	public boolean equals(Object o) {
		if(o instanceof Citris) {
			return color == ((Citris)o).color && rotten == ((Citris)o).rotten && taste == ((Citris)o).taste;
		}
		else {
			return false;
		}
	}
	
public static void main(String[] args) {
	Citris c = new Citris("good", "white", true);
	System.out.println(c.toString());

}
}