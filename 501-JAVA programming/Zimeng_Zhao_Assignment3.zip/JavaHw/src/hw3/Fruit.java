package hw3;

public class Fruit {
	String color;
	Boolean rotten;
	static int next_id;
	int id;
	
	Fruit(){
		next_id++;
		id = next_id;
		
	}
	
	Fruit(String color, Boolean rotten){
		next_id++;
		id = next_id;
		this.color = color;
		this.rotten = rotten;
	}
	
	public String getColor(){
		return this.color;//谁调用这个方法 返回谁的color
	}
	
	public void setColor(String color) {
		this.color = color;
	}
	
	public boolean isRotten() {
		return rotten;//rotten本身就是一个bool值
	}
	
	public void setRotten(boolean rotten) {
		this.rotten = rotten;
	}
	
	public int getId() {
		return this.id;
	}
	
	public boolean equals(Object o) {
		if(o instanceof Fruit) {
			return color == ((Fruit)o).color && rotten == ((Fruit)o).rotten;
		}
		else {
			return false;
		}
	}
	
	public String toString() {//overiding toString method
		return " color : " + this.getColor() + " rotten : " + this.isRotten() + " id : " + this.getId() +" class : " + getClass().getName(); 
		
	}

	public static void main(String[] args) {
		
		Fruit f = new Fruit("white", false);
		Fruit m = new Fruit("white", false);
		System.out.println(f.toString());
		System.out.println(f.equals(m));
	}

}
