/**
 * Zimeng Zhao 20012231
 */


package application;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Line;
import javafx.scene.paint.Color;

public class Grid extends Application {
	
	public void start(Stage primaryStage) {
		Pane pane = new Pane();
		Scene scene = new Scene(pane,400,400);
		
		double column = 3;//must be double, int 3/2==1
		for(int i = 0; i < 2; i++) {
			Line line = new Line();
			line.setStroke(Color.RED);
			line.startXProperty().bind(pane.widthProperty().divide(column));
			line.startYProperty().bind(pane.layoutYProperty());
			line.endXProperty().bind(line.startXProperty());
			line.endYProperty().bind(pane.heightProperty());
			pane.getChildren().add(line);
			column /= 2;
		}
		
		double row = 3;
		for(int i = 0; i < 2; i++) {
			Line line = new Line();
			line.setStroke(Color.BLUE);
			line.startXProperty().bind(pane.layoutXProperty());
			line.startYProperty().bind(pane.heightProperty().divide(row));
			line.endXProperty().bind(pane.widthProperty());
			line.endYProperty().bind(line.startYProperty());
			pane.getChildren().add(line);
			row /= 2;
		}
		primaryStage.setScene(scene);
		primaryStage.show();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

}
