/**
 * Zimeng Zhao 20012231
 */

package application;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.layout.Pane;

public class CheckerBroad extends Application {
	
	public void start(Stage primaryStage) {
		
		int columns = 8;
		int rows = 8;
		int width = 400;
		
		Pane pane = new Pane();
		Scene scene = new Scene(pane,width,width);
		

		
		for(int i = 0; i < columns; i++) {
			for(int j = 0; j <rows; j++) {
				Rectangle square = new Rectangle(j * (width / 8),i * (width / 8), width / 8, width / 8);
				if(i % 2 == 0) {
					if(j % 2 == 0) {
						square.setFill(Color.WHITE);
					}
					if(j % 2 != 0) {
						square.setFill(Color.BLACK);
					}
				}
				if(i % 2 != 0) {
					if(j % 2 == 0) {
						square.setFill(Color.BLACK);
					}
					if(j % 2 != 0) {
						square.setFill(Color.WHITE);
					}
				}
				pane.getChildren().add(square);
			}
		}
		primaryStage.setScene(scene);
		primaryStage.show();
		
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

}
