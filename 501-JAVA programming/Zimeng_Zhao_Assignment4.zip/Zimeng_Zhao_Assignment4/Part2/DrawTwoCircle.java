/**
 * Zimeng Zhao 20012231
 */


package application;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Line;
import javafx.scene.shape.Circle;
import javafx.scene.text.Text;
import javafx.scene.paint.Color;

public class DrawTwoCircle extends Application {
	
	public void start(Stage primaryStage) {
		Pane pane = new Pane();
		Scene scene = new Scene(pane);
		
		Circle circle1 = new Circle(15 + Math.random()*100, 15 + Math.random()*100, 15);
		Circle circle2 = new Circle(15 + Math.random()*100, 15 + Math.random()*100, 15);
		circle1.setStroke(Color.BLACK);
		circle2.setStroke(Color.BLACK);
		// in order to hide the line in circle
		circle1.setFill(Color.WHITE);
		circle2.setFill(Color.WHITE);
		
		Line line = new Line(circle1.getCenterX(), circle1.getCenterY(), circle2.getCenterX(), circle2.getCenterY());
		
		Text text1 = new Text(circle1.getCenterX(), circle1.getCenterY(), "1");
		Text text2 = new Text(circle2.getCenterX(), circle2.getCenterY(), "2");
		
		pane.getChildren().addAll(line, circle1, circle2, text1, text2);
		
		primaryStage.setScene(scene);
		primaryStage.show();
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		launch(args);
	}

}
