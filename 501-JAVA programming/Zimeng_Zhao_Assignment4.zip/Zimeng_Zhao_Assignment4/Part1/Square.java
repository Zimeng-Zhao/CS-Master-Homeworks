/**
 * Zimeng Zhao 20012231
 */

package hw4;

public class Square extends Geometric implements Colorable{

	private double side = 0;
	
	//constructors
	public Square() {
		super();
	}
	
	public Square(double side) {
		super();
		this.side = side;
	}
	
	public Square(double side, String color) {
		super(color);
		this.side = side;
	}
	
	//getter and setter methods
	public double getter() {
		return this.side;
	}
	
	public void setter(double side) {
		this.side = side;
	}
	
	//implements howtoColor()
	public void howToColor() {
		System.out.println("color all four sides");
	}
	
	//implements getArea()
	public double getArea() {
		return Math.pow(this.side, 2);
	}
	
	//implements getPerimeter()
	public double getPerimeter() {
		return this.side * 4;
	}
}
