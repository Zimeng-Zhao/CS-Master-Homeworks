/**
 * Zimeng Zhao 20012231
 */

package hw4;

public abstract class Geometric {

	private String color;
	
	//constructors
	protected Geometric(){
		
	}
	
	protected Geometric(String color) {
		this.color = color;
	}
	
	//setter and getter methods
	public String getColor() {
		return this.color;
	}
	
	public void setColor(String color) {
		this.color = color;
	}
	
	//abstract methods
	public abstract double getArea();
	
	public abstract double getPerimeter();
	
	
}
