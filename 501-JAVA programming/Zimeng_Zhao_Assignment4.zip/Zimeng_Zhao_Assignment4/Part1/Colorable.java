/**
 * Zimeng Zhao 20012231
 */

package hw4;

public interface Colorable {

	public abstract void howToColor();
}
