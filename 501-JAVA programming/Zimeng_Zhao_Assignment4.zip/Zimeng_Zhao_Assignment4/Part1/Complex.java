/**
 * Zimeng Zhao 20012231
 */

package hw4;


public class Complex implements Cloneable, Comparable<Complex>{

	private double real = 0;
	private double imaginary = 0;
	
	public Complex(){
		
	}
	
	public Complex(double a){
		real = a;
	}
	
	public Complex(double a, double b){
		real = a;
		imaginary = b;
	}
	
	public double getRealPart() {
		return real;
	}
	
	public double getImaginaryPart() {
		return imaginary;
	}
	
	public Complex add(Complex c) {
	
		double newReal = real + c.getRealPart();
		double newImaginary = imaginary + c.getImaginaryPart();
		Complex result = new Complex(newReal,newImaginary);
		return result;
	}
	
	public Complex subtract(Complex c) {
		double newReal = real - c.getRealPart();
		double newImaginary = imaginary - c.getImaginaryPart();
		Complex result = new Complex(newReal,newImaginary);
		return result;
	}
	
	public Complex multiply(Complex c) {
		double newReal = real * c.getRealPart() - imaginary * c.getImaginaryPart();
		double newImaginary = imaginary * c.getRealPart() + real * c.getImaginaryPart();
		Complex result = new Complex(newReal,newImaginary);
		return result;
	}
	
	public Complex divide(Complex c) {
		double newReal = (real * c.getRealPart() + imaginary * c.getImaginaryPart()) / (Math.pow(c.getRealPart(), 2) + Math.pow(c.getImaginaryPart(), 2));
		double newImaginary = (imaginary * c.getRealPart() - real * c.getImaginaryPart()) / (Math.pow(c.getRealPart(), 2) + Math.pow(c.getImaginaryPart(), 2));
		Complex result = new Complex(newReal,newImaginary);
		return result;
	}
	
	public double abs() {
		double abs = Math.sqrt(Math.pow(real, 2) + Math.pow(imaginary, 2));
		return abs;
	}
	
	@Override
	public String toString() {
		if(imaginary == 0) {
			return real + ""; 
		}
		else if(imaginary > 0){
			return real + "+" + imaginary + "i"; 
		}
		else {
			return real + "" + imaginary + "i";
		}
	}
	@Override
	public int compareTo(Complex o){
		if(this.abs() < o.abs()) {
			return -1;
		}
		else if (this.abs() > o.abs()) {
			return 1;
		}
		else {
			return 0;
		}
	}
	
	@Override
	public Complex clone() {
		try {
			return (Complex)super.clone();
		}
		catch(CloneNotSupportedException ex) {
			return null;
		}
	}
	
	
//	public static void main(String[] args) {
//	Complex c1 = new Complex(3,1);
//	Complex c2 = new Complex(1,1);Complex a=new Complex(0,3);
//	  Complex b=new Complex(4,6);
//	  Complex c=new Complex(1);
//	  System.out.println(c);
//	  System.out.println(a);
//	  System.out.println(a.add(b));
//	  System.out.println(a.abs());
//	  System.out.println(a.compareTo(b));
//	  System.out.println(a.multiply(b));
//	  System.out.println(a.divide(b));
//	  System.out.println(a.subtract(b));
//	  System.out.println(a.clone());
//	System.out.println(c1.compareTo(c2));
//	System.out.println(c1.add(c2));
//	System.out.println(c1.subtract(c2));
//	System.out.println(c1.multiply(c2));
//	System.out.println(c1.divide(c2));
//
//}
	
	}

