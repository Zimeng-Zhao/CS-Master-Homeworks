/**
 * Zimeng Zhao 20012231
 */

package hw4;

public class GeometricTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Geometric[] Geometrics = new Square[6];
		Geometrics[0] = new Square(1);
		Geometrics[1] = new Square(2,"white");
		Geometrics[2] = new Square(3);
		Geometrics[3] = new Square(4);
		Geometrics[4] = new Square(5,"blue");
		Geometrics[5] = new Square(6);
		
		for(int i = 0; i < Geometrics.length; i++) {
			if(Geometrics[i] instanceof Colorable && Geometrics[i].getColor() != null) {
			((Colorable)Geometrics[i]).howToColor();
			}
			System.out.println(Geometrics[i].getArea());
			System.out.println(Geometrics[i].getPerimeter());
			System.out.println("----------------------");
			
		}
	}

}
